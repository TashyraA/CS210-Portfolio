#include "GroceryTracker.h"
#include <fstream>
#include <iostream>

using namespace std;

GroceryTracker::GroceryTracker() {}

void GroceryTracker::readInputFile(const string& filename) {
    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open input file " << filename << endl;
        return;
    }

    string item;
    while (inputFile >> item) {
        itemFrequency[item]++;
    }

    inputFile.close();
}

void GroceryTracker::writeBackupFile(const string& filename) {
    ofstream outputFile(filename);
    if (!outputFile.is_open()) {
        cerr << "Error: Unable to open output file " << filename << endl;
        return;
    }

    for (const auto& pair : itemFrequency) {
        outputFile << pair.first << " " << pair.second << endl;
    }

    outputFile.close();
}

int GroceryTracker::getItemFrequency(const string& item) const {
    auto it = itemFrequency.find(item);
    return (it != itemFrequency.end()) ? it->second : 0;
}

void GroceryTracker::printItemList() const {
    for (const auto& pair : itemFrequency) {
        cout << pair.first << " " << pair.second << endl;
    }
}

void GroceryTracker::printHistogram() const {
    for (const auto& pair : itemFrequency) {
        cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            cout << "*";
        }
        cout << endl;
    }
}
