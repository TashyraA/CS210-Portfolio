#ifndef GROCERY_TRACKER_H
#define GROCERY_TRACKER_H

#include <map>
#include <string>

class GroceryTracker {
private:
    std::map<std::string, int> itemFrequency;

public:
    void readInputFile(const std::string& filename);
    void writeBackupFile(const std::string& filename);
    int getItemFrequency(const std::string& item) const;
    void printItemList() const;
    void printHistogram() const;
};

#endif
