#include "GroceryTracker.h"
#include <iostream>

using namespace std;

int main() {
    GroceryTracker tracker;
    tracker.readInputFile("input.txt");

    int choice;
    do {
        cout << "\nMenu Options:\n";
        cout << "1. Get frequency of a specific item\n";
        cout << "2. Print list with item frequencies\n";
        cout << "3. Print histogram\n";
        cout << "4. Write backup file\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string item;
                cout << "Enter the item: ";
                cin >> item;
                cout << "Frequency of " << item << ": " << tracker.getItemFrequency(item) << endl;
                break;
            }
            case 2:
                tracker.printItemList();
                break;
            case 3:
                tracker.printHistogram();
                break;
            case 4:
                tracker.writeBackupFile("frequency.dat");
                cout << "Backup file written successfully.\n";
                break;
            case 5:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice. Please enter a number between 1 and 5.\n";
        }
    } while (choice != 5);

    return 0;
}
