#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// Investment Calculator class
class InvestmentCalculator {
private:
    double initialInvestmentAmount;
    double monthlyDeposit;
    double annualInterestRate;
    int numberOfYears;

public:
    // Constructor
    InvestmentCalculator(double initialAmount, double deposit, double interestRate, int years) {
        initialInvestmentAmount = initialAmount;
        monthlyDeposit = deposit;
        annualInterestRate = interestRate;
        numberOfYears = years;
    }

    // Function to calculate future value
    double calculateFutureValue() {
        double futureValue = initialInvestmentAmount;
        double monthlyInterestRate = annualInterestRate / 100 / 12;
        int totalMonths = numberOfYears * 12;

        for (int i = 0; i < totalMonths; ++i) {
            futureValue = (futureValue + monthlyDeposit) * (1 + monthlyInterestRate);
        }

        return futureValue;
    }

    // Function to display investment summary
    void displayInvestmentSummary() {
        cout << fixed << setprecision(2);
        cout << "Initial Investment Amount: $" << initialInvestmentAmount << endl;
        cout << "Monthly Deposit: $" << monthlyDeposit << endl;
        cout << "Annual Interest Rate: " << annualInterestRate << "%" << endl;
        cout << "Number of Years: " << numberOfYears << endl << endl;

        cout << setw(4) << "Year" << setw(22) << "Year End Balance" << setw(22) << "Year End Earned Interest" << endl;
        cout << "---------------------------------------------------------------" << endl;

        double futureValueWithoutDeposit = initialInvestmentAmount;
        double futureValueWithDeposit = initialInvestmentAmount;
        double totalInterestWithoutDeposit = 0;
        double totalInterestWithDeposit = 0;

        for (int year = 1; year <= numberOfYears; ++year) {
            double monthlyInterestRate = annualInterestRate / 100 / 12;
            int monthsInYear = year * 12;

            for (int i = 0; i < monthsInYear; ++i) {
                futureValueWithoutDeposit *= (1 + monthlyInterestRate);
                futureValueWithDeposit = (futureValueWithDeposit + monthlyDeposit) * (1 + monthlyInterestRate);
            }

            double earnedInterestWithoutDeposit = futureValueWithoutDeposit - initialInvestmentAmount;
            double earnedInterestWithDeposit = futureValueWithDeposit - (initialInvestmentAmount + monthlyDeposit * monthsInYear);

            totalInterestWithoutDeposit += earnedInterestWithoutDeposit;
            totalInterestWithDeposit += earnedInterestWithDeposit;

            cout << setw(4) << year << setw(20) << "$" << futureValueWithoutDeposit << setw(20) << "$" << earnedInterestWithoutDeposit << endl;
            cout << setw(4) << year << setw(20) << "$" << futureValueWithDeposit << setw(20) << "$" << earnedInterestWithDeposit << endl;
        }

        cout << "---------------------------------------------------------------" << endl;
        cout << "Total Interest without Additional Monthly Deposits: $" << totalInterestWithoutDeposit << endl;
        cout << "Total Interest with Additional Monthly Deposits: $" << totalInterestWithDeposit << endl;
    }
};

// Main function
int main() {
    double initialAmount, deposit, interestRate;
    int years;

    // Input
    cout << "Initial Investment Amount: $";
    cin >> initialAmount;

    cout << "Monthly Deposit: $";
    cin >> deposit;

    cout << "Annual Interest Rate (%): ";
    cin >> interestRate;

    cout << "Number of Years: ";
    cin >> years;

    // Create InvestmentCalculator object
    InvestmentCalculator calculator(initialAmount, deposit, interestRate, years);

    // Display investment summary
    calculator.displayInvestmentSummary();

    return 0;
}
