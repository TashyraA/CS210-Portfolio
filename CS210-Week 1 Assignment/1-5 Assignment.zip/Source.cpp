#include <iostream>

using namespace std;

int main() {
    // Developer: Tashyra Adams
    // Date: 3/9/2024
    // Purpose: Output "Hello, World!" in C++

    cout << "Hello, World!" << endl;

    return 0;
}
