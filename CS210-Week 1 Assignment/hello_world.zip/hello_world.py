# Developer: [Your Name]
# Date: [Current Date]
# Purpose: This program prints "Hello, World!" to the console.

# Print "Hello, World!" to the console
print("Hello, World!")
